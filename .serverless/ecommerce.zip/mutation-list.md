<!-- M registerOrganization
M updateOrganization
M removeOrganization

Q organizations
Q organizationById

M addChannel
M updateChannel
M removeChannel

M openLocation
M updateLocationCapacity
M updateLocationTaxRate
M closeLocation

M addProduct
M updateProduct
M removeProduct -->

<!-- Q locationsByOrganization
Q locationsByGeo -->

M scheduleEvent
M rescheduleEvent
M updateEvent
M cancelEvent

<!-- M addVariant
M updateVariant
M removeVariant -->

<!-- M addOffer
M updateOffer
M removeOffer -->

M createOrder
<!-- M addOrderItem
M updateOrderItem
M removeOrderItem -->

<!-- M addPaymentOptions
M convertPlaidToStripe -->
M addOrderToken

M confirmOrder
M refundOrder
M transferOrder
M reassignOrder
