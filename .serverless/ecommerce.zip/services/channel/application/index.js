exports.getViewer = async (token) => ({
  roles: [ 'administrator' ]
})
