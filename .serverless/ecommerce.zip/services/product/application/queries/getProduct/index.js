const assert = require('assert')
const curry = require('lodash.curry')

const domain = (viewer, { product }) => {
  if (product.removed) {
    assert(viewer.roles.includes('administrator'), 'Must be an administrator to view removed products')
  }
  return product
}

const application = curry(async (domain, repository, viewer, id) => {
  const product = await repository.get(id)
  return domain(viewer, { product })
})

exports.domain = domain
exports.application = application
exports.getProduct = application(domain)
