require('dotenv').load()
const { fromGlobalId, toGlobalId, connectionFromArray } = require('graphql-relay')
const assert = require('assert')
const memoize = require('lodash.memoize')
const Monk = require('monk')
const uuid = require('uuid/v4')
const gql = require('graphql-tag')

const connection = memoize(url => new Monk(url))
const collection = memoize(name => connection(process.env.MONGODB_URL).get(name))

const ORDER_SOURCE = 'order.source'
const ORDER_VIEW = 'order.view'

const definition = gql`
  extend type Query {
    order(id: ID!): Order
    orders(first: Int, last: Int, before: String, after: String): OrderConnection!
  }

  type OrderConnection {
    edges: [ OrderEdge! ]!
    pageInfo: PageInfo
  }
  type OrderEdge {
    node: Order
    cursor: String
  }
  type Order {
    id: ID!
    items: [ OrderItem! ]!

    salesTax: Currency
    subtotal: Currency
    total: Currency
    amountPaid: Currency
    amountRefunded: Currency

    confirmationToken: String

    created: DateTime!
    updated: DateTime!
  }
  type OrderItem {
    variantId: ID!

    """ Price of product when it was added to the order """
    price: Currency

    """ Number of product on this order """
    quantity: Int!
    taxRate: Float
    taxIncluded: Boolean!
  }

  extend type Mutation {
    createOrder(input: CreateOrderInput!): CreateOrderResponse

    addOrderItem(input: AddOrderItemInput!): AddOrderItemResponse
    removeOrderItem(input: RemoveOrderItemInput!): RemoveOrderItemResponse

    selectFulfillment(input: SelectFulfillmentInput!): SelectFulfillmentResponse
    selectOffer(input: SelectOfferInput!): SelectOfferResponse

    chargeOrder(input: ChargeOrderInput!): ChargeOrderResponse

    refundOrder(input: RefundOrderInput!): RefundOrderResponse
    transferOrder(input: TransferOrderInput!): TransferOrderResponse
    reassignOrder(input: ReassignOrderInput!): ReassignOrderResponse
    confirmOrder(input: ConfirmOrderInput!): ConfirmOrderResponse
  }


  """ Create order """
  input CreateOrderInput {
    clientMutationId: ID!
    customerId: ID
  }
  type CreateOrderResponse {
    clientMutationId: ID!
    order: Order!
  }

  input AddOrderItemInput {
    clientMutationId: ID!
    id: ID!
    variantId: ID!
    quantity: Int = 1
  }
  type AddOrderItemResponse {
    clientMutationId: ID!
    order: Order!
  }

  input RemoveOrderItemInput {
    clientMutationId: ID!
    id: ID!
    variantId: ID!
    quantity: Int
  }
  type RemoveOrderItemResponse {
    clientMutationId: ID!
    order: Order!
  }

  input SelectFulfillmentInput {
    clientMutationId: ID!
    id: ID!
  }
  type SelectFulfillmentResponse {
    clientMutationId: ID!

  }
  input SelectOfferInput {
    clientMutationId: ID!
    id: ID!
  }
  type SelectOfferResponse {
    clientMutationId: ID!

  }

  """ Pay for the order """
  input ChargeOrderInput {
    clientMutationId: ID!
    """ Order ID created from reserving products """
    id: ID!
    """ Customer Name """
    name: String!
    """ Customer Email """
    email: String!
    """ Payment token """
    source: String!
  }
  type ChargeOrderResponse {
    clientMutationId: ID!
    order: Order!
  }

  """ Refund (or partially refund) a customers payment """
  input RefundOrderInput {
    clientMutationId: ID!
    id: ID!
    """ Number of products to refund. Defaults to whole order """
    variantId: ID
    quantity: Int
  }
  type RefundOrderResponse {
    clientMutationId: ID!
    order: Order!
  }

  """ Transfer products to another event """
  input TransferOrderInput {
    clientMutationId: ID!
    """ Order ID """
    id: ID!
    """ Order products are transferring to """
    eventId: ID!
    """ Amount of products to transfer """
    products: Int!
  }
  type TransferOrderResponse {
    clientMutationId: ID!
    sourceOrder: Order!
    destinationOrder: Order!
  }

  """ Let other people pick up products at willcall """
  input ReassignOrderInput {
    clientMutationId: ID!
    id: ID!
    to: String!
    from: String!
  }
  type ReassignOrderResponse {
    clientMutationId: ID!
    order: Order!
  }

  input ConfirmOrderInput {
    clientMutationId: ID!
    id: ID!
    token: String!
  }
  type ConfirmOrderResponse {
    clientMutationId: ID!
    order: Order!
  }
`

function defaultValue (field, value) {
  return (source) => {
    const val = source[field]
    if (val == null) return value
    return val
  }
}

const resolvers = {
  Query: {
    order: refetchOrder(),
    async orders (source, args, { viewer }) {
      const orders = await collection(ORDER_VIEW).find({})
      return connectionFromArray(orders, args)
    }
  },
  Order: {
    id: ({ id }) => toGlobalId('Order', id),
    items: defaultValue('items', []),
    subtotal: defaultValue('subtotal', 0),
    total: defaultValue('total', 0),
    salesTax: defaultValue('salesTax', 0),
    amountPaid: defaultValue('amountPaid', 0),
    amountRefunded: defaultValue('amountRefunded', 0)
  },
  OrderItem: {
    taxIncluded: defaultValue('taxIncluded', false),
  },
  Mutation: {
    async createOrder (source, { input: { clientMutationId, ...input } }, { viewer }) {
      const id = uuid()
      const now = Date.now()
      await collection(ORDER_SOURCE).insert({
        id,
        ...input,
        _timestamp: now,
        _type: 'OrderCreated'
      })
      await collection(ORDER_VIEW).insert({
        id,
        ...input,
        created: now,
        updated: now
      })
      return { clientMutationId, id }
    },
    async addOrderItem (source, { input: { clientMutationId, id, ...input } }, { viewer }) {
      id = fromGlobalId(id).id
      const now = Date.now()
      const order = await getOrder(id)
      await collection(ORDER_SOURCE).insert({
        id,
        ...input,
        _timestamp: now,
        _type: 'OrderItemAdded'
      })
      const items = updateItemQuantity(order.items, input.variantId, input.quantity)
      await collection(ORDER_VIEW).update({ id }, { $set: { items } })
      return { clientMutationId, id }
    },
    async removeOrderItem (source, { input: { clientMutationId, id, ...input } }, { viewer }) {
      id = fromGlobalId(id).id
      const now = Date.now()
      const order = await getOrder(id)
      await collection(ORDER_SOURCE).insert({
        id,
        ...input,
        _timestamp: now,
        _type: 'OrderItemAdded'
      })
      const items = updateItemQuantity(order.items, input.variantId, input.quantity * -1)
      await collection(ORDER_VIEW).update({ id }, { $set: { items } })
      return { clientMutationId, id }
    },
    async chargeOrder (source, { input }, { viewer }) {

    },
    async refundOrder (source, { input }, { viewer }) {

    },
    async transferOrder (source, { input }, { viewer }) {

    },
    async reassignOrder (source, { input }, { viewer }) {

    }
  },
  CreateOrderResponse: {
    order: refetchOrder()
  },
  AddOrderItemResponse: {
    order: refetchOrder()
  },
  RemoveOrderItemResponse: {
    order: refetchOrder()
  },
  ChargeOrderResponse: {
    order: refetchOrder()
  },
  RefundOrderResponse: {
    order: refetchOrder()
  },
  TransferOrderResponse: {
    sourceOrder: refetchOrder(),
    destinationOrder: refetchOrder()
  },
  ReassignOrderResponse: {
    order: refetchOrder()
  },
  ConfirmOrderResponse: {
    order: refetchOrder()
  }
}

function getOrder (id) {
  return collection(ORDER_VIEW).findOne({ id })
}
function refetchOrder (field = 'id') {
  return async (source, args, { viewer }) => {
    return getOrder(args.id || source.id)
  }
}

function updateItemQuantity (items = [], variantId, quantity) {
  let found = false
  const reduced = items.reduce((prev, item) => {
    if (item.variantId === variantId) {
      item.quantity = quantity === 0 ? 0 : item.quantity + quantity
      found = true
    }
    if (item.quantity > 0) prev.push(item)
    return prev
  }, [])
  if (!found && quantity > 0) reduced.push({ variantId, quantity })
  return reduced
}

exports.definition = definition
exports.resolvers = resolvers
