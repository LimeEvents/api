const { makeExecutableSchema } = require('graphql-tools')
const merge = require('lodash.merge')
const product = require('./product')

const services = [ product ]

const typeDefs = services.map(({ definition }) => definition)
const resolvers = services.reduce((prev, { resolvers }) => merge(prev, resolvers), {})

console.log(typeDefs)

exports.product = product
exports.schema = makeExecutableSchema({ typeDefs, resolvers })
