# Services

# Product

>A marketing object around selling a Thing

# Variant

>A Thing available for purchase via an Offer

# Offer

>Details of how to transact for a Variant

# Event

>Thing that happens at a point in time for a duration

# Order

>
